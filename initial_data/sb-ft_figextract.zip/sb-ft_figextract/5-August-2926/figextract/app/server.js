const express  = require('express');
const path     = require('path');
const https    = require('https');
const http     = require('http');
const crypto   = require('crypto');
const fs       = require('fs');
const figma    = require('./figmaClient');

const app  = express();
const PORT = process.env.PORT || 3017;
const HOST = process.env.HOST || '127.0.0.1';
const MAX_IDS_PER_REQUEST = 25;

// ── Config ───────────────────────────────────────────────────────────────────
const ADMIN_PASSWORD  = process.env.ADMIN_PASSWORD  || ')h]$\\r,=!,[3x_-#c-vb,kz2;?#';
const SESSION_SECRET  = process.env.SESSION_SECRET  || crypto.randomBytes(32).toString('hex');
const CODES_FILE      = process.env.CODES_FILE      || path.join(__dirname, '..', 'codes.json');
const COOKIE_MAX_AGE  = 30 * 24 * 60 * 60 * 1000; // 30 days
const ADMIN_ROUTE     = '/sultan';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── Codes store ──────────────────────────────────────────────────────────────
function loadCodes() {
  try {
    if (!fs.existsSync(CODES_FILE)) return [];
    return JSON.parse(fs.readFileSync(CODES_FILE, 'utf8'));
  } catch { return []; }
}

function saveCodes(codes) {
  fs.mkdirSync(path.dirname(CODES_FILE), { recursive: true });
  fs.writeFileSync(CODES_FILE, JSON.stringify(codes, null, 2), 'utf8');
}

function generateCode() {
  const part = () => crypto.randomBytes(2).toString('hex').toUpperCase();
  return `SBFT-${part()}-${part()}`;
}

// ── Cookie helpers ────────────────────────────────────────────────────────────
function sign(value, secret) {
  const hmac = crypto.createHmac('sha256', secret).update(value).digest('hex');
  return `${value}.${hmac}`;
}

function unsign(signed, secret) {
  const dot = signed.lastIndexOf('.');
  if (dot < 0) return null;
  const value = signed.slice(0, dot);
  const expected = crypto.createHmac('sha256', secret).update(value).digest('hex');
  const actual   = signed.slice(dot + 1);
  if (actual.length !== expected.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(actual), Buffer.from(expected))) return null;
  return value;
}

function parseCookies(req) {
  const raw = req.headers.cookie || '';
  return Object.fromEntries(raw.split(';').map(c => {
    const [k, ...v] = c.trim().split('=');
    return [k, decodeURIComponent(v.join('='))];
  }));
}

function setCookie(res, name, value, maxAge) {
  res.setHeader('Set-Cookie',
    `${name}=${encodeURIComponent(value)}; Max-Age=${Math.floor(maxAge / 1000)}; Path=/; HttpOnly; SameSite=Strict`
  );
}

function clearCookie(res, name) {
  res.setHeader('Set-Cookie', `${name}=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict`);
}

// ── Auth middleware ───────────────────────────────────────────────────────────
function getUserSession(req) {
  const cookies = parseCookies(req);
  const raw = cookies['figextract_session'];
  if (!raw) return null;
  const value = unsign(raw, SESSION_SECRET);
  if (!value) return null;
  // value = "code:SBFT-XXXX-YYYY"
  const match = value.match(/^code:(.+)$/);
  return match ? match[1] : null;
}

function getAdminSession(req) {
  const cookies = parseCookies(req);
  const raw = cookies['figextract_admin'];
  if (!raw) return false;
  const value = unsign(raw, ADMIN_PASSWORD);
  return value === 'admin';
}

function requireUser(req, res, next) {
  // Admin session is always allowed to use the app
  if (getAdminSession(req)) {
    req.userCode = 'admin';
    return next();
  }
  const code = getUserSession(req);
  if (!code) return res.status(401).json({ error: 'Unauthorised', redirect: '/login' });
  // Verify code is still active
  const codes = loadCodes();
  const entry = codes.find(c => c.code === code);
  if (!entry || !entry.active) return res.status(401).json({ error: 'Access revoked', redirect: '/login' });
  if (entry.expiresAt && new Date(entry.expiresAt) < new Date()) {
    return res.status(401).json({ error: 'Access code expired', redirect: '/login' });
  }
  req.userCode = code;
  next();
}

function requireAdmin(req, res, next) {
  if (!getAdminSession(req)) return res.status(401).json({ error: 'Admin auth required' });
  next();
}

// ── Job store ─────────────────────────────────────────────────────────────────
const JOB_TTL_MS = 2 * 60 * 60 * 1000;
const jobs = new Map();

function createJob(type, meta = {}) {
  const id = crypto.randomUUID();
  jobs.set(id, { id, type, status: 'pending', progress: 0, message: '', result: null, error: null, createdAt: Date.now(), meta });
  setTimeout(() => jobs.delete(id), JOB_TTL_MS);
  return id;
}

function updateJob(id, patch) {
  const job = jobs.get(id);
  if (job) jobs.set(id, { ...job, ...patch });
}

function getJobPublic(id) {
  const job = jobs.get(id);
  if (!job) return null;
  const { result, ...pub } = job;
  pub.hasResult = result !== null;
  return pub;
}

// ── App setup ─────────────────────────────────────────────────────────────────
app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: false }));

// Static files — serve login and admin from public/
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'], maxAge: '1h' }));

// ── Auth routes ───────────────────────────────────────────────────────────────

// User login
app.post('/auth/login', (req, res) => {
  const code = (req.body.code || '').trim().toUpperCase();
  if (!code) return res.status(400).json({ error: 'Код не указан' });

  const codes = loadCodes();
  const entry = codes.find(c => c.code === code);

  if (!entry)        return res.status(403).json({ error: 'Неверный код доступа' });
  if (!entry.active) return res.status(403).json({ error: 'Код деактивирован' });
  if (entry.expiresAt && new Date(entry.expiresAt) < new Date()) {
    return res.status(403).json({ error: 'Срок действия кода истёк' });
  }
  if (entry.maxUses > 0 && entry.usedCount >= entry.maxUses) {
    return res.status(403).json({ error: 'Лимит использований исчерпан' });
  }

  // Increment use count
  entry.usedCount = (entry.usedCount || 0) + 1;
  entry.lastUsedAt = new Date().toISOString();
  saveCodes(codes);

  const token = sign(`code:${code}`, SESSION_SECRET);
  setCookie(res, 'figextract_session', token, COOKIE_MAX_AGE);
  res.json({ ok: true });
});

// Auth check — used by index.html on load to verify session is valid
app.get('/auth/check', (req, res) => {
  if (getAdminSession(req)) return res.json({ ok: true, role: 'admin' });
  const code = getUserSession(req);
  if (!code) return res.status(401).json({ error: 'Unauthorised' });
  const codes = loadCodes();
  const entry = codes.find(c => c.code === code);
  if (!entry || !entry.active) return res.status(401).json({ error: 'Access revoked' });
  if (entry.expiresAt && new Date(entry.expiresAt) < new Date()) {
    return res.status(401).json({ error: 'Expired' });
  }
  res.json({ ok: true, role: 'user' });
});

// User logout
app.post('/auth/logout', (req, res) => {
  clearCookie(res, 'figextract_session');
  res.json({ ok: true });
});

// Admin login
app.post('/auth/admin-login', (req, res) => {
  const password = req.body.password || '';
  if (password !== ADMIN_PASSWORD) {
    return res.status(403).json({ error: 'Неверный пароль' });
  }
  const token = sign('admin', ADMIN_PASSWORD);
  setCookie(res, 'figextract_admin', token, COOKIE_MAX_AGE);
  res.json({ ok: true });
});

// Admin logout
app.post('/auth/admin-logout', (req, res) => {
  clearCookie(res, 'figextract_admin');
  res.json({ ok: true });
});

// ── Admin API routes (protected) ──────────────────────────────────────────────

// List all codes
app.get('/sultan/api/codes', requireAdmin, (_req, res) => {
  res.json(loadCodes());
});

// Add a new code
app.post('/sultan/api/codes', requireAdmin, (req, res) => {
  const { label, expiresAt, maxUses } = req.body;
  const codes = loadCodes();
  const newCode = {
    code:       generateCode(),
    label:      (label || 'Без имени').trim(),
    expiresAt:  expiresAt || null,
    maxUses:    parseInt(maxUses) || 0,
    usedCount:  0,
    active:     true,
    createdAt:  new Date().toISOString(),
    lastUsedAt: null,
  };
  codes.push(newCode);
  saveCodes(codes);
  res.json(newCode);
});

// Toggle active status
app.patch('/sultan/api/codes/:code/toggle', requireAdmin, (req, res) => {
  const codes = loadCodes();
  const entry = codes.find(c => c.code === req.params.code);
  if (!entry) return res.status(404).json({ error: 'Code not found' });
  entry.active = !entry.active;
  saveCodes(codes);
  res.json(entry);
});

// Delete a code permanently
app.delete('/sultan/api/codes/:code', requireAdmin, (req, res) => {
  let codes = loadCodes();
  const before = codes.length;
  codes = codes.filter(c => c.code !== req.params.code);
  if (codes.length === before) return res.status(404).json({ error: 'Code not found' });
  saveCodes(codes);
  res.json({ ok: true });
});

// Update code details (label, expiry, maxUses)
app.patch('/sultan/api/codes/:code', requireAdmin, (req, res) => {
  const codes = loadCodes();
  const entry = codes.find(c => c.code === req.params.code);
  if (!entry) return res.status(404).json({ error: 'Code not found' });
  if (req.body.label    !== undefined) entry.label    = req.body.label;
  if (req.body.expiresAt !== undefined) entry.expiresAt = req.body.expiresAt || null;
  if (req.body.maxUses  !== undefined) entry.maxUses  = parseInt(req.body.maxUses) || 0;
  saveCodes(codes);
  res.json(entry);
});

// ── Admin panel page ──────────────────────────────────────────────────────────
app.get(ADMIN_ROUTE, (req, res) => {
  if (!getAdminSession(req)) {
    return res.redirect(`${ADMIN_ROUTE}/login`);
  }
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.get(`${ADMIN_ROUTE}/login`, (_req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-login.html'));
});

// ── Health ────────────────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ ok: true, service: 'figextract' }));

// ── Helpers ───────────────────────────────────────────────────────────────────
let isProfessionalPlan = null;
let planCheckedAt      = null;

function getToken(req) {
  const h = req.headers['x-figma-token'];
  const b = req.body && req.body.token;
  return (typeof h === 'string' && h.trim()) || (typeof b === 'string' && b.trim()) || '';
}

function getFileKey(input) {
  if (!input || typeof input !== 'string') return null;
  const m = input.match(/figma\.com\/(?:file|design|proto)\/([a-zA-Z0-9_-]+)/);
  if (m) return m[1];
  if (/^[a-zA-Z0-9_-]{10,}$/.test(input.trim())) return input.trim();
  return null;
}

async function figmaRequestWithToken(pathname, token) {
  const res = await figma.figmaFetch(`https://api.figma.com/v1${pathname}`, {
    headers: { 'X-Figma-Token': token },
  });
  return res.json;
}

function collectNodes(node, acc = [], pageName = '', ancestorPath = []) {
  if (!node) return acc;
  const currentPage = node.type === 'CANVAS' ? (node.name || pageName) : pageName;
  const supported = new Set(['FRAME','GROUP','COMPONENT','COMPONENT_SET','INSTANCE','RECTANGLE','ELLIPSE','VECTOR','POLYGON','STAR','LINE','TEXT']);
  // ancestorPath grows with every non-root node
  const myPath = (node.type === 'DOCUMENT' || node.type === 'CANVAS')
    ? ancestorPath
    : [...ancestorPath, node.name || 'Untitled'];
  if (supported.has(node.type)) {
    acc.push({ id: node.id, name: node.name || 'Untitled', type: node.type, page: currentPage || 'Unknown', path: myPath });
  }
  if (Array.isArray(node.children)) {
    for (const child of node.children) collectNodes(child, acc, currentPage, myPath);
  }
  return acc;
}

function downloadImage(url) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https') ? https : http;
    lib.get(url, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302) return downloadImage(res.headers.location).then(resolve).catch(reject);
      if (res.statusCode !== 200) return reject(new Error(`Image download failed: ${res.statusCode}`));
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
      res.on('error', reject);
    }).on('error', reject);
  });
}

function safeFilename(name) { return name.replace(/[/\\?%*:|"<>]/g, '-').replace(/\s+/g, '_').slice(0, 100); }

function crc32(buf) {
  crc32.t = crc32.t || (() => { const t = new Uint32Array(256); for (let i=0;i<256;i++){let c=i;for(let j=0;j<8;j++)c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1);t[i]=c;}return t; })();
  let crc=0xffffffff;
  for(let i=0;i<buf.length;i++)crc=crc32.t[(crc^buf[i])&0xff]^(crc>>>8);
  return(crc^0xffffffff)>>>0;
}

function buildZip(entries) {
  const locals=[],central=[];let offset=0;
  for(const e of entries){
    const nb=Buffer.from(e.name,'utf8');const crc=crc32(e.buffer);const now=new Date();
    const dt=(now.getHours()<<11)|(now.getMinutes()<<5)|(now.getSeconds()>>1);
    const dd=((now.getFullYear()-1980)<<9)|((now.getMonth()+1)<<5)|now.getDate();
    const lh=Buffer.alloc(30+nb.length);
    lh.writeUInt32LE(0x04034b50,0);lh.writeUInt16LE(20,4);lh.writeUInt16LE(0x800,6);
    lh.writeUInt16LE(0,8);lh.writeUInt16LE(dt,10);lh.writeUInt16LE(dd,12);
    lh.writeUInt32LE(crc,14);lh.writeUInt32LE(e.buffer.length,18);lh.writeUInt32LE(e.buffer.length,22);
    lh.writeUInt16LE(nb.length,26);lh.writeUInt16LE(0,28);nb.copy(lh,30);
    locals.push(lh,e.buffer);
    const cd=Buffer.alloc(46+nb.length);
    cd.writeUInt32LE(0x02014b50,0);cd.writeUInt16LE(20,4);cd.writeUInt16LE(20,6);
    cd.writeUInt16LE(0x800,8);cd.writeUInt16LE(0,10);cd.writeUInt16LE(dt,12);cd.writeUInt16LE(dd,14);
    cd.writeUInt32LE(crc,16);cd.writeUInt32LE(e.buffer.length,20);cd.writeUInt32LE(e.buffer.length,24);
    cd.writeUInt16LE(nb.length,28);cd.writeUInt16LE(0,30);cd.writeUInt16LE(0,32);
    cd.writeUInt16LE(0,34);cd.writeUInt16LE(0,36);cd.writeUInt32LE(0,38);
    cd.writeUInt32LE(offset,42);nb.copy(cd,46);central.push(cd);
    offset+=lh.length+e.buffer.length;
  }
  const cdb=Buffer.concat(central);const eocd=Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50,0);eocd.writeUInt16LE(0,4);eocd.writeUInt16LE(0,6);
  eocd.writeUInt16LE(entries.length,8);eocd.writeUInt16LE(entries.length,10);
  eocd.writeUInt32LE(cdb.length,12);eocd.writeUInt32LE(offset,16);eocd.writeUInt16LE(0,20);
  return Buffer.concat([...locals,cdb,eocd]);
}

// ── Background workers ────────────────────────────────────────────────────────
async function runExtractJob(jobId, { token, fileKey, format, scale }) {
  try {
    updateJob(jobId, { status: 'running', progress: 2, message: 'Подключение к Figma API…' });
    const fileData = await figmaRequestWithToken(`/files/${fileKey}`, token);
    const nodes    = collectNodes(fileData.document, []);
    const chunks   = [];
    for (let i = 0; i < nodes.length; i += MAX_IDS_PER_REQUEST) chunks.push(nodes.slice(i, i + MAX_IDS_PER_REQUEST));
    updateJob(jobId, { progress: 5, message: `Найдено ${nodes.length} узлов. Запрос изображений…` });
    const imageMap = new Map();
    for (let i = 0; i < chunks.length; i++) {
      if (i > 0) await sleep(3000);
      const chunk  = chunks[i];
      const ids    = chunk.map((n) => n.id).join(',');
      const query  = `/images/${fileKey}?ids=${encodeURIComponent(ids)}&format=${encodeURIComponent(format)}&scale=${encodeURIComponent(scale)}`;
      const data   = await figmaRequestWithToken(query, token);
      const images = data.images || {};
      for (const item of chunk) { if (images[item.id]) imageMap.set(item.id, images[item.id]); }
      const pct = 5 + Math.round(((i + 1) / chunks.length) * 90);
      updateJob(jobId, { progress: pct, message: `Чанк ${i + 1} из ${chunks.length} обработан…` });
    }
    const items = nodes.filter((n) => imageMap.has(n.id)).map((n) => ({ ...n, url: imageMap.get(n.id) }));
    updateJob(jobId, { status: 'done', progress: 100, message: `Готово — ${items.length} изображений из ${nodes.length} узлов.`, result: { fileKey, format, scale, totalNodes: nodes.length, totalImages: items.length, items } });
  } catch (err) {
    updateJob(jobId, { status: 'error', progress: 0, error: err.message || 'Unknown error' });
  }
}

async function runZipJob(jobId, { items, format, zipStructure = 'flat' }) {
  try {
    const total = items.length;
    updateJob(jobId, { status: 'running', progress: 2, message: `Скачивание изображений (0 / ${total})…` });
    const entries = []; const usedNames = new Map();

    for (let i = 0; i < items.length; i++) {
      const item = items[i]; if (!item.url) continue;

      let base;
      if (zipStructure === 'hierarchy' && Array.isArray(item.path) && item.path.length > 0) {
        // Use full Figma layer hierarchy as folder path.
        // item.path already includes the node itself as last segment, e.g.:
        // ['Homepage', 'Catalog', 'Cars', 'Clio']
        // → Homepage/Catalog/Cars/Clio.png
        const parts = item.path.map(safeFilename);
        const fileName = parts.pop(); // last segment = filename
        const folder = [safeFilename(item.page || 'Unknown'), ...parts].join('/');
        base = `${folder}/${fileName}.${format}`;
      } else {
        // Flat: page/name.ext (original behaviour)
        base = `${safeFilename(item.page || 'Unknown')}/${safeFilename(item.name || 'image')}.${format}`;
      }

      // Deduplicate: if same path seen before, append counter before extension
      const cnt = usedNames.get(base) || 0; usedNames.set(base, cnt + 1);
      if (cnt > 0) base = base.replace(`.${format}`, `_${cnt + 1}.${format}`);

      try { const buf = await downloadImage(item.url); entries.push({ name: base, buffer: buf }); }
      catch (e) { console.warn(`[zip-job] skipping ${item.name}: ${e.message}`); }

      const pct = 5 + Math.round(((i + 1) / total) * 85);
      updateJob(jobId, { progress: pct, message: `Скачивание изображений (${i + 1} / ${total})…` });
    }

    updateJob(jobId, { progress: 95, message: 'Упаковка ZIP…' });
    const zip = buildZip(entries);
    updateJob(jobId, { status: 'done', progress: 100, message: `ZIP готов — ${(zip.length / 1024 / 1024).toFixed(1)} MB`, result: zip, meta: { format, zipStructure, itemCount: entries.length, sizeBytes: zip.length } });
  } catch (err) {
    updateJob(jobId, { status: 'error', progress: 0, error: err.message || 'Unknown error' });
  }
}

// ── Protected API routes ──────────────────────────────────────────────────────
app.post('/api/extract', requireUser, (req, res) => {
  const token   = getToken(req);
  const fileKey = getFileKey(req.body?.url || req.body?.fileKey || '');
  const format  = ['png','jpg','svg','pdf'].includes(req.body?.format) ? req.body.format : 'png';
  const scale   = Math.min(Math.max(Number(req.body?.scale || 2), 1), 3);
  if (!token)   return res.status(400).json({ error: 'Missing Figma token' });
  if (!fileKey) return res.status(400).json({ error: 'Invalid Figma file URL or key' });
  const jobId = createJob('extract', { fileKey, format, scale });
  runExtractJob(jobId, { token, fileKey, format, scale });
  res.json({ jobId });
});

app.post('/api/download-zip', requireUser, (req, res) => {
  const { items, format, zipStructure } = req.body || {};
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: 'No items provided' });
  const fmt = ['png','jpg','svg','pdf'].includes(format) ? format : 'png';
  const struct = zipStructure === 'hierarchy' ? 'hierarchy' : 'flat';
  const jobId = createJob('zip', { itemCount: items.length, format: fmt, zipStructure: struct });
  runZipJob(jobId, { items, format: fmt, zipStructure: struct });
  res.json({ jobId });
});

app.get('/api/job/:id', requireUser, (req, res) => {
  const job = getJobPublic(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found or expired' });
  res.json(job);
});

app.get('/api/job/:id/result', requireUser, (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found or expired' });
  if (job.status !== 'done') return res.status(409).json({ error: 'Job not done yet', status: job.status });
  if (job.type !== 'extract') return res.status(400).json({ error: 'Use /download for zip jobs' });
  res.json(job.result);
});

app.get('/api/job/:id/download', requireUser, (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found or expired' });
  if (job.status !== 'done') return res.status(409).json({ error: 'Job not done yet', status: job.status });
  if (job.type !== 'zip') return res.status(400).json({ error: 'Not a zip job' });
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="figma-export.zip"');
  res.setHeader('Content-Length', job.result.length);
  res.end(job.result);
});

app.get('/figma/queue-status', requireUser, (_req, res) => res.json(figma.queue.getStatus()));
app.get('/figma/plan-status',  (_req, res) => res.json({ isProfessionalPlan, teamId: process.env.FIGMA_TEAM_ID || null, checkedAt: planCheckedAt }));

// ── Start ─────────────────────────────────────────────────────────────────────
async function start() {
  try { isProfessionalPlan = await figma.verifyProPlan(); }
  catch (err) { console.error(`[start] plan verification error: ${err.message}`); isProfessionalPlan = false; }
  planCheckedAt = new Date().toISOString();
  app.listen(PORT, HOST, () => console.log(`FigExtract listening on http://${HOST}:${PORT}`));
}

start();
module.exports = app;
